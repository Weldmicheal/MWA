const fib = require("./fibonacci")



console.log("fib of 30 is: " + fib(30))

console.log("fib of -15 is: " + fib(-15))

