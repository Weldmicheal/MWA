angular.module("myPropperApp").controller("AboutController", AboutController)

function AboutController(){
    const vm = this
    vm.bio = "This is the bio"
}