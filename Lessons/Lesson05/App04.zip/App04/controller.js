angular.module("myPropperApp").controller("MyPropperController", MyPropperController)

function MyPropperController(){
    const vm = this
    vm.name="Jack"
}